#include <iostream>

using namespace std;

int main()
{
    double result=0;
    double avg=0;
    int number=0;
    double sum=0;
            cout << "Welcome to the GPA Calculator!" << endl;
        do{
            cout << "Enter the GPA of the student.\nA negative GPA will end the loop and return the average of all the positive GPA's entered." << endl;
            cin>>result;
            if (result >= 0)
            {
                sum+=result;
                number++;
            }
            }
        while(result>=0);
            avg=sum/number;


            cout << "The average GPA entered was " <<avg << endl;


            return 0;
}
